
const answers={
"umrah visa":"DestiFly Travels Umrah Visa assistance. Hamari team visa requirements aur process mein guide karti hai. Latest approval time ya rate ke liye office se confirm karein.",
"hajj":"DestiFly Travels Hajj travel assistance provide karta hai. Package, visa aur travel details ke liye hamari team se rabta karein.",
"air tickets":"All-airline ticketing assistance available. Apni route aur travel date bhej dein, team aapko options guide karegi.",
"hotels":"Makkah aur Madinah hotel options ke liye destination, dates aur room sharing bata dein.",
"umrah packages":"Umrah package ke liye days, airline, hotel category aur budget bata dein. Team suitable option suggest karegi.",
"contact":"DestiFly Travels\\n📍 M.A Plaza near TCS Office, Kahror Pacca\\n📞 0306 8157051\\n✉️ destiflytravels@gmail.com"
};
function openChat(){document.getElementById('chat').classList.remove('hidden');document.getElementById('input').focus()}
function closeChat(){document.getElementById('chat').classList.add('hidden')}
function addMsg(t,c){let d=document.createElement('div');d.className='msg '+c;d.innerHTML=t.replace(/\n/g,'<br>');let m=document.getElementById('messages');m.appendChild(d);m.scrollTop=m.scrollHeight}
function ask(q){openChat();addMsg(q,'user');let key=q.toLowerCase();let a=answers[key]||"Assalam-o-Alaikum! 👋 Main DestiFly AI Assistant hoon. Umrah visa, Hajj, air tickets, hotels, packages ya contact ke baare mein pooch sakte hain.";setTimeout(()=>addMsg(a,'bot'),250)}
function send(){let i=document.getElementById('input'),q=i.value.trim();if(!q)return;i.value='';ask(q)}
